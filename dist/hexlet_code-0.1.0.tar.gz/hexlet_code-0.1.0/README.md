https://codeclimate.com/github/irusnak74/python-project-49/maintainability
