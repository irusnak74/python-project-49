import random


def generate_rand_num(a=1, b=35):
    return random.randint(a, b)
