#!/usr/bin/env python3


from brain_games.even import is_even


def main():
    get_num_and_even_answer()


if __name__ == "__main__":
    main()
